# .github/workflows

Pipelines de CI/CD serão entregues no **Módulo 15**.
