# apps/api — Backend (NestJS)

Este diretório receberá o código-fonte completo do backend a partir do
**Módulo 3** (Autenticação) em diante. A estrutura de módulos do NestJS está
documentada em `docs/ARCHITECTURE.md` na raiz do projeto.
