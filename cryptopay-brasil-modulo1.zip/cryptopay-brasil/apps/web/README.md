# apps/web — Frontend (Next.js 15)

Este diretório receberá o código-fonte completo do frontend a partir do
**Módulo 9** (Setup Next.js + PWA) em diante.
