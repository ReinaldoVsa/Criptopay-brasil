# infra/nginx

Configurações de proxy reverso e SSL/Let's Encrypt serão entregues no
**Módulo 14**.
