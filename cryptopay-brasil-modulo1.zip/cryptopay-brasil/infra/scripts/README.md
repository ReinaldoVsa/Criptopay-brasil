# infra/scripts

Scripts de deploy, backup e restore serão entregues no **Módulo 14**.
